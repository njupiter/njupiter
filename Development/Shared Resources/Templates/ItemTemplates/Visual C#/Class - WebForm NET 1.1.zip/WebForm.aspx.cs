using System;

namespace $rootnamespace$ {

	public class $safeitemrootname$ : System.Web.UI.Page {

	    protected void Page_Load(object sender, EventArgs e) {

	    }
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)	{
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}
		#endregion

	}

}